#!/usr/bin/env node
import whyIsNodeRunning from './index.js';
whyIsNodeRunning();
