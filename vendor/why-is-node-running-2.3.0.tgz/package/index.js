/** Offline-compatible diagnostics fallback for why-is-node-running@2.3.0. */
export default function whyIsNodeRunning() {
  const handles = typeof process._getActiveHandles === 'function' ? process._getActiveHandles() : [];
  const requests = typeof process._getActiveRequests === 'function' ? process._getActiveRequests() : [];
  if (handles.length || requests.length) {
    console.error(`There are ${handles.length + requests.length} active handle(s) or request(s) keeping the process running.`);
  }
  return { handles, requests };
}
