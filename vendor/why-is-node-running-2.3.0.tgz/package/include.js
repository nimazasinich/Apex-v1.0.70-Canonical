import whyIsNodeRunning from './index.js';
process.on('SIGINFO', () => whyIsNodeRunning());
